<?php
$koneksi = mysqli_connect("localhost", "root", "", "ukk_25");

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
