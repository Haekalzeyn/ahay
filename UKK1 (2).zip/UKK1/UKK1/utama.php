<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>UKK 2025</title>
  <style>
     { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { height: 100%; font-family: sans-serif; }
    body { display: flex; flex-direction: column; }
    header { background:rgb(254, 254, 254); color: black; text-align: left; padding: 10px; }
     footer { background:rgb(71, 25, 235); color: black; text-align: center; padding: 10px; }
    .login-btn { position: absolute; right: 20px; top: 20px; background: orange; border: none; padding: 5px 10px; 
                 border-radius: 5px; color: #fff; text-decoration: none;}
    .main { flex: 1; display: flex; justify-content: center; align-items: center; padding: 20px; gap: 20px; flex-wrap: wrap; }
    img { max-width: 60%; height: 58%; }
    .icon-login { max-widht: 60%; height: 58%;}
    .text { max-width: 500px; font-size: 14px; } 
  </style>
</head>
<body>
  <header>
    <h2>WEBSITE UKK 2025</h2>
    <a href="register.php" class="login-btn">
  <img src="LogoRPL.jpeg" class="icon-login" style="width: 16px; height: 16px; vertical-align: middle; margin-right: 5px;">
  Login
</a>

  </header>

  <div class="main">
    <img src="GambarTB2.jpg">
    <div class="text">
    <h2>REKAYASA PERANGKAT LUNAK</h2>
      <p><strong>VISI</strong><br>
      "menjadikan lulusan yang tangguh dalam teknologi informasi berkarakter dan siap menghadapi Globalisasi."</p>

      <p><strong>MISI</strong><br>
      1. Melaksanakan pengembangan dan implementasi kurikulum.<br>
      2. Menyiapkan sarana dan prasarana pembelajaran produktif dengan lengkap dan berkualitas.<br>
      3. Menjadikan insan yang kreatif, produkt dan inovatif dalam pengembangan.</p>

      <p><strong>KOMPETENSI KELAS XI KOMPUTER & INFORMATIKA</strong><br>
      1. Dapat merencanakan dan membuat kebutuhan basis data (Database)<br>
      2. Dapat membuat dan mendesain halaman web statis dan dinamis dengan bahasa program CSS, HTML, PHP, Javascript dsb.<br>
      3. Dapat membuat website secara native maupun menggunakan framework  (CI atau Laravel)<br>
      4. Dapat membuat aplikasi berbasis desktop dengan menggunakan VB.NET</p>
    </div>
  </div>

  <footer>
    © 2024-2025 UKK Jurusan Perangkat Lunak
  </footer>
</body>
</html>
